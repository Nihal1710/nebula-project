`timescale 1ns/1ns
module tb_fir;
     reg clk;
     reg rst;
     reg[15:0] sample_in;
     wire[15:0] sample_out;
    fir_filter #(.N(8), .WIDTH(16)) dut (
        .clk(clk), .rst(rst),
        .sample_in(sample_in),
        .sample_out(sample_out)
    );
    
    always #5 clk=~clk;

    initial
    begin
    clk=0;
    rst=1;
    #6 rst=0;

    #8 sample_in=0;
    #10 sample_in=1;
    #10 sample_in=2;
    #10 sample_in=3;
    #10 sample_in=4;
    #10 sample_in=5;
    #10 sample_in=6;
    #10 sample_in=7;
    #10sample_in=8;
    #10 sample_in=9;
    #10 sample_in=10;
     #50
     $display("sample_out = %d", sample_out);

#50
$finish;


    end
endmodule